OK, here's the source for MiniShare. It's messy. It originally was much more messy.
Then I started to fix the source code, chickened out and released it as open source,
hoping someone with even more spare time would fix it for me.

There's a lot of stupid things(tm) in the code, including tons of global variables
etc. newbie stuff (I started this project in order to finally learn C and Windows
coding, with little experience of projects at this scale). So bear with it. 

The code should compile with MinGW, just run make in the directory src/. Compiled 
binaries can be found in bin/english (for the English version), bin/finnish etc.
You also need the MIME type files and config files from the binary distribution.

-tero a.k.a. kometbomb

P.S. I didn't see it important to include the installer scripts etc.
