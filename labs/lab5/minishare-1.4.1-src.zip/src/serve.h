void _cdecl serve(void* _cons);
