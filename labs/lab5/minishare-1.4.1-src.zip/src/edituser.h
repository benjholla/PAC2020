BOOL CALLBACK edituserproc (HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
