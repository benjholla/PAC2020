void addtolog(int i,char *msg);
